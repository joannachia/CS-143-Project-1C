<!DOCTYPE html>
<html>
<head><title>CS143 Project 1C Demo</title></head>

<body>
<h2>Navigation</h2>

<table style="width:50%">
  <tr>
    <th style="text-align:left">Add:</th>
    <th style="text-align:left">Browsing:</th>
    <th style="text-align:left">Search:</th>
  </tr>
  <tr>
    <td style="text-align:left"><a href="add_actor.php" target="main">Actor</a></td>
    <td><a href="b_actor.php" target="main">By Actor</a></td>
    <td><a href="search.php" target="main">Actors or Movies</a></td>
  </tr>
  <tr>
    <td><a href="add_movie.php" target="main">Movie</a></td>
    <td><a href="b_movie.php" target="main">By Movies</a></td>
  </tr>
  <tr>
    <td><a href="add_actor_movie.php" target="main">Actor to Movie</a></td>
  </tr>
</table>

</body>
</html>