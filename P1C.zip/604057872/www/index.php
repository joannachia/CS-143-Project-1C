
<html>
<head>
	<title>Movie Database</title>
</head>


<FRAMESET ROWS="25%,75%" FRAMEBORDER="0" BORDER="0">
<FRAME NAME="dir" SRC="header.php">
<FRAME NAME="main" SRC="search.php">
</FRAMESET>

</html>
