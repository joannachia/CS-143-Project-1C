Authors: 
	Ashish Lal 604057872
	Joanna Chia 804043577

We implemented all of the add functionality in "Add Actor", "Add Movie", and "Add Actor to Movie".

We also implemented two browsing pages. One lets you see information about an actor and the movies he/she was in.
The other allows one to see information about a movie and the actors and their roles played in that movie.

We finally implemented the search functionality with a search page that allows one to search with multi-word search functionality. 

We finally implemented test cases with the Selenium IDE.
We added in functionality in the test cases to wait for the elements to be clicked/selected to be present first and made two pauses of 3 seconds for the large database queries getting a list of all movies and actors to fully load. This was done in case the test cases were run at a fast speed.

Both of us equally shared the workload. Joanna started the project by working on the add actor and add movie functionality and then we met up and I worked on the browse by actor and browse by movie functionality while she worked on the search functionality. Later, we worked on the project separately and I made some usability and formatting changes and preventing insertion of empty tuples. Then, I finished up with creating the Selenium test cases.